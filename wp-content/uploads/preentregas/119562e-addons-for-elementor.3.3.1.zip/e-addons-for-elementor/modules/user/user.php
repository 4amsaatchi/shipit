<?php

namespace EAddonsForElementor\Modules\User;

use EAddonsForElementor\Base\Module_Base;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class User extends Module_Base {

    public function __construct() {
        parent::__construct();
    }

}
