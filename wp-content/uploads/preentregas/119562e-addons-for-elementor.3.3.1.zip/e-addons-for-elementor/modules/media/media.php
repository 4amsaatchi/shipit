<?php

namespace EAddonsForElementor\Modules\Media;

use EAddonsForElementor\Base\Module_Base;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Media extends Module_Base {

    public function __construct() {
        parent::__construct();
    }

}
