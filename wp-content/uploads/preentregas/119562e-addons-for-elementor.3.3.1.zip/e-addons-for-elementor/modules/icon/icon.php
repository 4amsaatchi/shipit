<?php

namespace EAddonsForElementor\Modules\Icon;

use EAddonsForElementor\Base\Module_Base;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Icon extends Module_Base {

    public function __construct() {
        parent::__construct();
    }

}
