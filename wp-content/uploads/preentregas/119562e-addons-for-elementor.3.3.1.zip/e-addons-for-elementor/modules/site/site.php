<?php

namespace EAddonsForElementor\Modules\Site;

use EAddonsForElementor\Base\Module_Base;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Site extends Module_Base {

    public function __construct() {
        parent::__construct();
    }

}
